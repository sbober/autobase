// Automatically generated migration based on Groovy script
changeSet(id:'@ID@', author:'@AUTHOR@') { 
  groovyChangeScript(script:'@SCRIPT@')
}
